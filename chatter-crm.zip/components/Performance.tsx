'use client'

import { useState, useEffect } from 'react'
import { useStore, calcSalary, fmt } from '@/lib/store'
import { QUALITE_CRITERES, MONTHS, WEEKS } from '@/lib/types'
import { Check, X } from 'lucide-react'

export default function Performance() {
  const { chatters, savePerformance, saveQualite } = useStore()

  // Commission form
  const [perfChatter, setPerfChatter] = useState('')
  const [perfMonth, setPerfMonth] = useState('4-2026')
  const [revealCA, setRevealCA] = useState('')
  const [revealPct, setRevealPct] = useState('')
  const [inflowCA, setInflowCA] = useState('')
  const [inflowPct, setInflowPct] = useState('')
  const [eurUsd, setEurUsd] = useState('0.92')
  const [saved, setSaved] = useState(false)

  // Quality form
  const [qualChatter, setQualChatter] = useState('')
  const [qualWeek, setQualWeek] = useState('S15')
  const [checks, setChecks] = useState<Record<string, boolean | null>>({})
  const [qualSaved, setQualSaved] = useState(false)

  useEffect(() => {
    if (chatters.length > 0) {
      setPerfChatter(String(chatters[0].id))
      setQualChatter(String(chatters[0].id))
    }
  }, [chatters])

  // Auto-fill commission % from chatter defaults
  useEffect(() => {
    const c = chatters.find(c => c.id === parseInt(perfChatter))
    if (c) {
      setRevealPct(String(c.revealPct))
      setInflowPct(String(c.inflowPct))
    }
  }, [perfChatter, chatters])

  const preview = (() => {
    const rCA = parseFloat(revealCA) || 0
    const rPct = parseFloat(revealPct) || 0
    const iCA = parseFloat(inflowCA) || 0
    const iPct = parseFloat(inflowPct) || 0
    const rate = parseFloat(eurUsd) || 0.92
    if (rCA === 0 && iCA === 0) return null
    return calcSalary({ id: '', chatterId: 0, month: '', revealCA: rCA, revealPct: rPct, inflowCA: iCA, inflowPct: iPct, eurUsd: rate })
  })()

  const handleSavePerf = () => {
    if (!perfChatter) return
    savePerformance({
      chatterId: parseInt(perfChatter),
      month: perfMonth,
      revealCA: parseFloat(revealCA) || 0,
      revealPct: parseFloat(revealPct) || 0,
      inflowCA: parseFloat(inflowCA) || 0,
      inflowPct: parseFloat(inflowPct) || 0,
      eurUsd: parseFloat(eurUsd) || 0.92,
    })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
    setRevealCA(''); setInflowCA('')
  }

  const qualScore = QUALITE_CRITERES.reduce((acc, c) => acc + (checks[c.id] === true ? c.weight : 0), 0)

  const handleSaveQual = () => {
    if (!qualChatter) return
    const finalChecks: Record<string, boolean> = {}
    QUALITE_CRITERES.forEach(c => { finalChecks[c.id] = checks[c.id] === true })
    saveQualite({ chatterId: parseInt(qualChatter), week: qualWeek, score: qualScore, checks: finalChecks })
    setChecks({})
    setQualSaved(true)
    setTimeout(() => setQualSaved(false), 2000)
  }

  return (
    <div className="space-y-5">
      {/* Commission data entry */}
      <div className="bg-white border border-gray-100 rounded-xl p-5">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Saisir données du mois</div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">Chatter</label>
            <select value={perfChatter} onChange={e => setPerfChatter(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900">
              {chatters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">Mois</label>
            <select value={perfMonth} onChange={e => setPerfMonth(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900">
              {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
            </select>
          </div>
        </div>

        <div className="text-xs font-semibold text-gray-400 mb-2 mt-4">Reveal <span className="font-normal text-gray-400">(TVA déjà déduite)</span></div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">CA Reveal (€)</label>
            <input type="number" value={revealCA} onChange={e => setRevealCA(e.target.value)} placeholder="1685.15" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">% commission</label>
            <input type="number" value={revealPct} onChange={e => setRevealPct(e.target.value)} placeholder="25" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900" />
          </div>
        </div>

        <div className="text-xs font-semibold text-gray-400 mb-2 mt-4">Inflow / OnlyFans <span className="font-normal text-gray-400">(montant brut $)</span></div>
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">CA Inflow ($)</label>
            <input type="number" value={inflowCA} onChange={e => setInflowCA(e.target.value)} placeholder="800" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">% commission</label>
            <input type="number" value={inflowPct} onChange={e => setInflowPct(e.target.value)} placeholder="25" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">Taux EUR/USD</label>
            <input type="number" value={eurUsd} onChange={e => setEurUsd(e.target.value)} step="0.001" className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900" />
          </div>
        </div>

        {/* Preview */}
        {preview && (
          <div className="bg-gray-50 rounded-xl p-4 mb-4">
            <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Aperçu du calcul</div>
            <div className="space-y-1.5">
              {[
                ['Reveal net (−18%)', fmt(preview.revealNet)],
                ['Commission Reveal', fmt(preview.revealCom)],
                ['Inflow net OF (−20%) en €', fmt(preview.inflowNet)],
                ['Commission Inflow', fmt(preview.inflowCom)],
              ].map(([label, val]) => (
                <div key={label} className="flex justify-between text-sm">
                  <span className="text-gray-400">{label}</span>
                  <span>{val}</span>
                </div>
              ))}
              <div className="flex justify-between text-sm font-semibold pt-2 border-t border-gray-200 mt-2">
                <span>Salaire total</span>
                <span className="text-blue-600">{fmt(preview.total)}</span>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={handleSavePerf}
          className={`text-sm font-medium px-4 py-2 rounded-lg transition-colors ${
            saved ? 'bg-green-600 text-white' : 'bg-gray-900 text-white hover:bg-gray-800'
          }`}
        >
          {saved ? '✓ Enregistré' : 'Enregistrer'}
        </button>
      </div>

      {/* Quality evaluation */}
      <div className="bg-white border border-gray-100 rounded-xl p-5">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Évaluation qualité</div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">Chatter</label>
            <select value={qualChatter} onChange={e => setQualChatter(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900">
              {chatters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1.5 font-medium">Semaine</label>
            <select value={qualWeek} onChange={e => setQualWeek(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gray-900">
              {WEEKS.map(w => <option key={w.value} value={w.value}>{w.label}</option>)}
            </select>
          </div>
        </div>

        <div className="space-y-1 mb-4">
          {QUALITE_CRITERES.map(c => (
            <div key={c.id} className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0">
              <div>
                <div className="text-sm">{c.label}</div>
                <div className="text-xs text-gray-400">{c.weight} pts</div>
              </div>
              <div className="flex gap-1.5">
                <button
                  onClick={() => setChecks(prev => ({ ...prev, [c.id]: true }))}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    checks[c.id] === true ? 'bg-green-100 text-green-700' : 'border border-gray-200 text-gray-300 hover:text-gray-500'
                  }`}
                >
                  <Check size={14} />
                </button>
                <button
                  onClick={() => setChecks(prev => ({ ...prev, [c.id]: false }))}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                    checks[c.id] === false ? 'bg-red-100 text-red-600' : 'border border-gray-200 text-gray-300 hover:text-gray-500'
                  }`}
                >
                  <X size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Score bar */}
        <div className="mb-4">
          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden mb-1.5">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                qualScore >= 80 ? 'bg-green-500' : qualScore >= 50 ? 'bg-amber-500' : 'bg-red-400'
              }`}
              style={{ width: `${qualScore}%` }}
            />
          </div>
          <div className="text-xs text-gray-400">Score qualité : <span className="font-semibold text-gray-700">{qualScore}/100</span></div>
        </div>

        <button
          onClick={handleSaveQual}
          className={`text-sm font-medium px-4 py-2 rounded-lg transition-colors ${
            qualSaved ? 'bg-green-600 text-white' : 'bg-gray-900 text-white hover:bg-gray-800'
          }`}
        >
          {qualSaved ? '✓ Enregistré' : 'Enregistrer évaluation'}
        </button>
      </div>
    </div>
  )
}

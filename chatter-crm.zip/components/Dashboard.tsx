'use client'

import { useState } from 'react'
import { useStore, calcSalary, getPrimesNet, getQualScore, fmtShort, fmt, monthLabel, initials, avatarColor } from '@/lib/store'
import { MONTHS } from '@/lib/types'

export default function Dashboard() {
  const [month, setMonth] = useState('4-2026')
  const { chatters, performances, primes, qualites } = useStore()

  const perfs = performances.filter(p => p.month === month)
  const totalCA = perfs.reduce((acc, p) => acc + p.revealCA + p.inflowCA * p.eurUsd, 0)
  const totalSalaires = perfs.reduce((acc, p) => acc + calcSalary(p).total, 0)
  const primesNet = getPrimesNet(primes, null, month)

  const ranked = [...perfs].sort((a, b) => calcSalary(b).total - calcSalary(a).total)

  return (
    <div>
      <div className="flex items-center gap-3 mb-5">
        <span className="text-sm text-gray-500">Période</span>
        <select
          value={month}
          onChange={e => setMonth(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-gray-900"
        >
          {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
        </select>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { label: 'CA total agence', value: fmtShort(totalCA), sub: 'Reveal + Inflow' },
          { label: 'Salaires à verser', value: fmtShort(totalSalaires), sub: `${perfs.length} chatter(s)` },
          { label: 'Chatters actifs', value: String(chatters.length), sub: 'ce mois' },
          { label: 'Primes nettes', value: fmtShort(primesNet), sub: 'ce mois' },
        ].map(m => (
          <div key={m.label} className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="text-xs text-gray-400 mb-1">{m.label}</div>
            <div className="text-xl font-semibold">{m.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{m.sub}</div>
          </div>
        ))}
      </div>

      {/* Ranking */}
      <div className="bg-white border border-gray-100 rounded-xl p-5">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Classement chatters — {monthLabel(month)}</div>
        {ranked.length === 0 ? (
          <div className="text-sm text-gray-400 py-4 text-center">Aucune donnée pour ce mois</div>
        ) : ranked.map((p, i) => {
          const c = chatters.find(c => c.id === p.chatterId)
          if (!c) return null
          const s = calcSalary(p)
          const qualScore = getQualScore(qualites, c.id)
          const primeMois = getPrimesNet(primes, c.id, month)
          return (
            <div key={p.id} className="flex items-center gap-3 py-3 border-b border-gray-50 last:border-0">
              <span className="text-sm font-medium text-gray-300 w-5">{i + 1}</span>
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 ${avatarColor(c.id)}`}>
                {initials(c.name)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{c.name}</div>
                <div className="text-xs text-gray-400">{c.platforms}</div>
              </div>
              <div className="text-right">
                {qualScore !== null && (
                  <div className={`text-xs font-medium px-2 py-0.5 rounded-md mb-1 inline-block ${
                    qualScore >= 80 ? 'bg-green-50 text-green-700' :
                    qualScore >= 50 ? 'bg-amber-50 text-amber-700' :
                    'bg-red-50 text-red-700'
                  }`}>{qualScore}/100</div>
                )}
                <div className="text-sm font-semibold">{fmt(s.total + primeMois)}</div>
                <div className="text-xs text-gray-400">commission</div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

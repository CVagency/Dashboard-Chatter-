'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { Chatter, Performance, QualiteEval, PrimeSanction, CalcResult } from './types'

interface Store {
  chatters: Chatter[]
  performances: Performance[]
  qualites: QualiteEval[]
  primes: PrimeSanction[]
  nextId: number

  addChatter: (c: Omit<Chatter, 'id' | 'createdAt'>) => void
  removeChatter: (id: number) => void

  savePerformance: (p: Omit<Performance, 'id'>) => void
  saveQualite: (q: Omit<QualiteEval, 'id' | 'createdAt'>) => void
  addPrime: (p: Omit<PrimeSanction, 'id'>) => void
  removePrime: (id: string) => void
}

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      chatters: [
        { id: 1, name: 'Cédric', platforms: 'Reveal + Inflow', revealPct: 25, inflowPct: 25, createdAt: '2026-04-01' },
        { id: 2, name: 'Mahery', platforms: 'Reveal + Inflow', revealPct: 30, inflowPct: 30, createdAt: '2026-04-01' },
      ],
      performances: [
        { id: 'p1', chatterId: 1, month: '4-2026', revealCA: 1685.15, revealPct: 25, inflowCA: 800, inflowPct: 25, eurUsd: 0.92 },
        { id: 'p2', chatterId: 2, month: '4-2026', revealCA: 2100, revealPct: 30, inflowCA: 1200, inflowPct: 30, eurUsd: 0.92 },
      ],
      qualites: [],
      primes: [],
      nextId: 3,

      addChatter: (c) => set((s) => ({
        chatters: [...s.chatters, { ...c, id: s.nextId, createdAt: new Date().toISOString() }],
        nextId: s.nextId + 1,
      })),

      removeChatter: (id) => set((s) => ({
        chatters: s.chatters.filter(c => c.id !== id),
      })),

      savePerformance: (p) => set((s) => {
        const existing = s.performances.findIndex(x => x.chatterId === p.chatterId && x.month === p.month)
        const entry = { ...p, id: `p-${Date.now()}` }
        if (existing >= 0) {
          const updated = [...s.performances]
          updated[existing] = entry
          return { performances: updated }
        }
        return { performances: [...s.performances, entry] }
      }),

      saveQualite: (q) => set((s) => ({
        qualites: [...s.qualites, { ...q, id: `q-${Date.now()}`, createdAt: new Date().toISOString() }],
      })),

      addPrime: (p) => set((s) => ({
        primes: [...s.primes, { ...p, id: `pr-${Date.now()}` }],
      })),

      removePrime: (id) => set((s) => ({
        primes: s.primes.filter(p => p.id !== id),
      })),
    }),
    { name: 'cvagency-crm-store' }
  )
)

export function calcSalary(p: Performance): CalcResult {
  const revealNet = p.revealCA * (1 - 0.18)
  const revealCom = revealNet * (p.revealPct / 100)
  const inflowNet = p.inflowCA * (1 - 0.20) * p.eurUsd
  const inflowCom = inflowNet * (p.inflowPct / 100)
  return { revealNet, revealCom, inflowNet, inflowCom, total: revealCom + inflowCom }
}

export function getPrimesNet(primes: PrimeSanction[], chatterId: number | null, month: string): number {
  return primes
    .filter(p => (chatterId === null || p.chatterId === chatterId) && p.month === month)
    .reduce((acc, p) => acc + (p.type === 'prime' ? p.amount : -p.amount), 0)
}

export function getQualScore(qualites: QualiteEval[], chatterId: number): number | null {
  const evals = qualites.filter(q => q.chatterId === chatterId)
  if (evals.length === 0) return null
  return evals[evals.length - 1].score
}

export function fmt(n: number): string {
  return n.toFixed(2) + ' €'
}

export function fmtShort(n: number): string {
  return Math.round(n).toLocaleString('fr-FR') + ' €'
}

export function monthLabel(month: string): string {
  const map: Record<string, string> = {
    '1-2026': 'Janvier 2026', '2-2026': 'Février 2026',
    '3-2026': 'Mars 2026', '4-2026': 'Avril 2026',
  }
  return map[month] || month
}

export function initials(name: string): string {
  return name.slice(0, 2).toUpperCase()
}

export function avatarColor(id: number): string {
  const colors = [
    'bg-blue-100 text-blue-700',
    'bg-teal-100 text-teal-700',
    'bg-orange-100 text-orange-700',
    'bg-purple-100 text-purple-700',
    'bg-pink-100 text-pink-700',
  ]
  return colors[(id - 1) % colors.length]
}
